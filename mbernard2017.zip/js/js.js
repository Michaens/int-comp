function WeightConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output2").innerHTML=(valNum*2.2046226218);
}


function DistanceConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output2").innerHTML=(valNum*.3048);
}

function WeightsConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output2").innerHTML=(valNum*0.45359237);
}

function DistancesConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output2").innerHTML=(valNum/.3048);
}
<!------------------------------------------------->

function VolumeConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output").innerHTML=(valNum*1000);
}

 
function MoneyConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output").innerHTML=(valNum*.81);
}
function VolumesConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output").innerHTML=(valNum*0.001);
}

 
function MoneysConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output").innerHTML=(valNum*1.23);
}


<!----------------------------------------------------------------------->
function FahrenheitConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output1").innerHTML=(valNum-32)/1.8;
}

function MilesConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output1").innerHTML=(valNum*1.609344);
}

function FahrenheitsConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output1").innerHTML=(valNum*1.8)+32;
}

function MileConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output1").innerHTML=(valNum*.621371);
}


<!-------------------------------------------------------------------------------------------------->

function SecondsConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output3").innerHTML=(valNum/60);
}

function AcreConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output3").innerHTML=(valNum*.40468564464278);
}

function SecondConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output3").innerHTML=(valNum*60);
}

function AcresConverter(valNum) {
  valNum = parseFloat(valNum);
  document.getElementById("output3").innerHTML=(valNum*2.47105);
}




